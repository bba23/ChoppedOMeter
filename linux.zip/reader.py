import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image
from PIL.ExifTags import TAGS
import piexif
import os
import math
import pygame
import sys

class ChoppedOMeter:
    def __init__(self, root):
        self.root = root
        self.root.title("Chopped-O-Meter Reader")
        self.root.geometry("600x550")
        self.root.configure(bg='#f0f0f0')
        
        # Set window icon (cross-platform)
        try:
            if sys.platform.startswith('linux'):
                # Linux uses PhotoImage with iconphoto
                icon_path = self.get_resource_path('reader.png')
                if os.path.exists(icon_path):
                    img = tk.PhotoImage(file=icon_path)
                    self.root.iconphoto(True, img)
            else:
                # Windows uses ico files
                icon_path = self.get_resource_path('reader.ico')
                if os.path.exists(icon_path):
                    self.root.iconbitmap(icon_path)
        except Exception as e:
            print(f"Could not load icon: {e}")
        
        # Initialize pygame mixer for audio
        pygame.mixer.init()
        
        # Main frame
        main_frame = tk.Frame(root, bg='#f0f0f0')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        title_label = tk.Label(main_frame, text="🔪 CHOPPED-O-METER 🔪", 
                              font=('Arial', 24, 'bold'), bg='#f0f0f0', fg='#d32f2f')
        title_label.pack(pady=10)
        
        # File selection button
        self.browse_button = tk.Button(main_frame, text="Select Image to Analyze", 
                                      command=self.browse_file, font=('Arial', 12),
                                      bg='#4CAF50', fg='white', padx=20, pady=10)
        self.browse_button.pack(pady=10)
        
        # File label
        self.file_label = tk.Label(main_frame, text="No file selected", 
                                  font=('Arial', 10), bg='#f0f0f0', fg='gray')
        self.file_label.pack()
        
        # Meter frame
        self.meter_frame = tk.Frame(main_frame, bg='#f0f0f0')
        self.meter_frame.pack(fill=tk.BOTH, expand=True, pady=20)
        
        # Canvas for meter
        self.canvas = tk.Canvas(self.meter_frame, width=400, height=250, bg='#f0f0f0', highlightthickness=0)
        self.canvas.pack()
        
        # Large percentage display
        self.percent_label = tk.Label(main_frame, text="", font=('Arial', 48, 'bold'), 
                                     bg='#f0f0f0', fg='#333')
        self.percent_label.pack(pady=5)
        
        # Result label
        self.result_label = tk.Label(main_frame, text="", font=('Arial', 16, 'bold'), 
                                    bg='#f0f0f0', fg='#333')
        self.result_label.pack(pady=10)
        
        # Description label
        self.desc_label = tk.Label(main_frame, text="", font=('Arial', 12), 
                                  bg='#f0f0f0', fg='#666', wraplength=500)
        self.desc_label.pack()
        
        self.draw_empty_meter()
        
    def draw_empty_meter(self):
        self.canvas.delete("all")
        # Draw meter background
        cx, cy = 200, 180
        radius = 120
        
        # Draw outer arc
        self.canvas.create_arc(cx-radius, cy-radius, cx+radius, cy+radius,
                              start=0, extent=180, outline='#333', width=3, style=tk.ARC)
        
        # Draw tick marks
        for i in range(11):
            angle = math.radians(180 - i * 18)
            x1 = cx + (radius - 10) * math.cos(angle)
            y1 = cy - (radius - 10) * math.sin(angle)
            x2 = cx + radius * math.cos(angle)
            y2 = cy - radius * math.sin(angle)
            self.canvas.create_line(x1, y1, x2, y2, fill='#333', width=2)
            
            # Add labels
            if i % 2 == 0:
                label_x = cx + (radius + 15) * math.cos(angle)
                label_y = cy - (radius + 15) * math.sin(angle)
                self.canvas.create_text(label_x, label_y, text=str(i*10), 
                                       font=('Arial', 10), fill='#333')
        
        # Draw center point
        self.canvas.create_oval(cx-5, cy-5, cx+5, cy+5, fill='#333', outline='')
        
    def draw_meter(self, value):
        self.draw_empty_meter()
        cx, cy = 200, 180
        radius = 100
        
        # Calculate needle angle
        angle = math.radians(180 - (value / 100) * 180)
        needle_x = cx + radius * math.cos(angle)
        needle_y = cy - radius * math.sin(angle)
        
        # Draw colored arc based on value
        if value < 30:
            color = '#4CAF50'  # Green
        elif value < 70:
            color = '#FFC107'  # Yellow
        else:
            color = '#F44336'  # Red
        
        # Draw filled arc
        self.canvas.create_arc(cx-radius+20, cy-radius+20, cx+radius-20, cy+radius-20,
                              start=180-(value/100)*180, extent=(value/100)*180, 
                              fill=color, outline='')
        
        # Draw needle
        self.canvas.create_line(cx, cy, needle_x, needle_y, fill='#222', width=4)
        self.canvas.create_oval(cx-8, cy-8, cx+8, cy+8, fill='#222', outline='')
        
    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select an image to analyze",
            filetypes=[("JPEG files", "*.jpg *.jpeg"), ("All files", "*.*")]
        )
        if filename:
            self.file_label.config(text=f"Analyzing: {os.path.basename(filename)}")
            self.root.update()  # Force UI update
            self.root.after(100, lambda: self.analyze_image(filename))  # Delay to show UI update
    
    def analyze_image(self, filename):
        try:
            # Check if it's a JPEG
            if not filename.lower().endswith(('.jpg', '.jpeg')):
                messagebox.showwarning("File Format", 
                    "This file is not a JPEG. Only JPEG files can contain chopped data.\n\n" +
                    "Use the Embedder app to process images first!")
                self.show_result(None)
                self.file_label.config(text="No file selected")
                return
            
            # Open image
            img = Image.open(filename)
            
            # Try to read EXIF data
            if 'exif' not in img.info:
                self.show_result(None)
                return
            
            exif_dict = piexif.load(img.info['exif'])
            
            # Check UserComment first
            chopped_value = None
            if piexif.ExifIFD.UserComment in exif_dict['Exif']:
                user_comment = exif_dict['Exif'][piexif.ExifIFD.UserComment]
                if isinstance(user_comment, bytes):
                    comment_str = user_comment.decode('utf-8', errors='ignore')
                    if comment_str.startswith('CHOPPED:'):
                        chopped_value = int(comment_str.split(':')[1])
            
            # If not found, check ImageDescription
            if chopped_value is None and piexif.ImageIFD.ImageDescription in exif_dict['0th']:
                desc = exif_dict['0th'][piexif.ImageIFD.ImageDescription]
                if isinstance(desc, bytes):
                    desc_str = desc.decode('utf-8', errors='ignore')
                    if 'CHOPPED_LEVEL:' in desc_str:
                        chopped_value = int(desc_str.split(':')[1])
            
            self.show_result(chopped_value)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read image: {str(e)}")
            self.show_result(None)
    
    def get_resource_path(self, filename):
        """Get absolute path to resource, works for dev and PyInstaller"""
        if hasattr(sys, '_MEIPASS'):
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            return os.path.join(sys._MEIPASS, filename)
        return os.path.abspath(filename)
    
    def play_sound(self, level):
        """Play MP3 file based on chopped level"""
        try:
            if level == 0:
                sound_file = "not_chopped.mp3"
            elif level < 30:
                sound_file = "barely_chopped.mp3"
            elif level < 50:
                sound_file = "moderately_chopped.mp3"
            elif level < 80:
                sound_file = "heavily_chopped.mp3"
            else:
                sound_file = "extremely_chopped.mp3"
            
            # Get correct path for the sound file
            sound_path = self.get_resource_path(sound_file)
            
            # Check if file exists and play it
            if os.path.exists(sound_path):
                pygame.mixer.music.stop()  # Stop any currently playing sound
                pygame.mixer.music.load(sound_path)
                pygame.mixer.music.play()
            else:
                print(f"Sound file not found: {sound_path}")  # Debug info
        except Exception as e:
            print(f"Error playing sound: {e}")  # Debug info
    
    def show_result(self, value):
        if value is None:
            self.draw_empty_meter()
            self.percent_label.config(text="")
            self.result_label.config(text="❌ NOT CHOPPED!", fg='#4CAF50')
            self.desc_label.config(text="This image has not been chopped. It's totally fine!")
        else:
            self.draw_meter(value)
            
            # Display large percentage
            self.percent_label.config(text=f"{value}%")
            
            # Play corresponding sound
            self.play_sound(value)
            
            if value == 0:
                status = "✅ NOT CHOPPED"
                color = '#4CAF50'
                desc = "sigma boy"
                self.percent_label.config(fg=color)
            elif value < 30:
                status = "✅ BARELY CHOPPED"
                color = '#4CAF50'
                desc = "just a tiny bit chopped"
                self.percent_label.config(fg=color)
            elif value < 50:
                status = "⚠️ MODERATELY CHOPPED"
                color = '#FF9800'
                desc = "look with caution"
                self.percent_label.config(fg=color)
            elif value < 80:
                status = "🔥 HEAVILY CHOPPED"
                color = '#FF5722'
                desc = "getting ugly!"
                self.percent_label.config(fg=color)
            else:
                status = "💀 EXTREMELY CHOPPED"
                color = '#F44336'
                desc = "maximum ugliness!"
                self.percent_label.config(fg=color)
            
            self.result_label.config(text=status, fg=color)
            self.desc_label.config(text=desc)

if __name__ == "__main__":
    root = tk.Tk()
    app = ChoppedOMeter(root)
    root.mainloop()