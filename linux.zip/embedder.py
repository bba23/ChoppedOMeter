import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image
from PIL.ExifTags import TAGS
import piexif
import os
import sys

class MetadataEmbedder:
    def __init__(self, root):
        self.root = root
        self.root.title("Chopped-O-Meter Embedder")
        self.root.geometry("500x400")
        
        # Set window icon (cross-platform)
        try:
            if sys.platform.startswith('linux'):
                # Linux uses PhotoImage with iconphoto
                icon_path = self.get_resource_path('embedder.png')
                if os.path.exists(icon_path):
                    img = tk.PhotoImage(file=icon_path)
                    self.root.iconphoto(True, img)
            else:
                # Windows uses ico files
                icon_path = self.get_resource_path('embedder.ico')
                if os.path.exists(icon_path):
                    self.root.iconbitmap(icon_path)
        except Exception as e:
            print(f"Could not load icon: {e}")
        
        # Style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Main frame
        main_frame = ttk.Frame(root, padding="20")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title_label = ttk.Label(main_frame, text="Chopped-O-Meter Embedder", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=2, pady=10)
        
        # File selection
        ttk.Label(main_frame, text="Selected Image:", font=('Arial', 10)).grid(row=1, column=0, sticky=tk.W, pady=5)
        self.file_label = ttk.Label(main_frame, text="No file selected", foreground="gray")
        self.file_label.grid(row=2, column=0, columnspan=2, sticky=tk.W, padx=20)
        
        ttk.Button(main_frame, text="Browse Image", command=self.browse_file).grid(row=3, column=0, columnspan=2, pady=10)
        
        # Number input
        ttk.Label(main_frame, text="Chopped Level (0-100):", font=('Arial', 10)).grid(row=4, column=0, sticky=tk.W, pady=5)
        self.number_var = tk.StringVar()
        self.number_entry = ttk.Entry(main_frame, textvariable=self.number_var, width=20)
        self.number_entry.grid(row=5, column=0, columnspan=2, pady=5)
        
        # Embed button
        self.embed_button = ttk.Button(main_frame, text="Embed Chopped Level", 
                                      command=self.embed_metadata, state=tk.DISABLED)
        self.embed_button.grid(row=6, column=0, columnspan=2, pady=20)
        
        # Status label
        self.status_label = ttk.Label(main_frame, text="", foreground="green")
        self.status_label.grid(row=7, column=0, columnspan=2, pady=5)
        
        self.selected_file = None
        
    def get_resource_path(self, filename):
        """Get absolute path to resource, works for dev and PyInstaller"""
        if hasattr(sys, '_MEIPASS'):
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            return os.path.join(sys._MEIPASS, filename)
        return os.path.abspath(filename)
    
    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select an image",
            filetypes=[("JPEG files", "*.jpg *.jpeg"), ("All files", "*.*")]
        )
        if filename:
            self.selected_file = filename
            self.file_label.config(text=os.path.basename(filename))
            self.embed_button.config(state=tk.NORMAL)
            self.status_label.config(text="")
    
    def embed_metadata(self):
        if not self.selected_file:
            messagebox.showerror("Error", "Please select an image first")
            return
        
        try:
            # Check file format
            if not self.selected_file.lower().endswith(('.jpg', '.jpeg')):
                response = messagebox.askyesno("File Format Warning", 
                    "This app works best with JPEG files.\nNon-JPEG files will be converted to JPEG format.\nThis will REPLACE your original file!\n\nContinue?")
                if not response:
                    return
            
            # Validate number
            chopped_value = int(self.number_var.get())
            if not 0 <= chopped_value <= 100:
                raise ValueError("Number must be between 0 and 100")
            
            # Open image
            img = Image.open(self.selected_file)
            
            # Prepare EXIF data
            exif_dict = {"0th": {}, "Exif": {}, "GPS": {}, "1st": {}}
            
            # Try to load existing EXIF data
            if 'exif' in img.info:
                exif_dict = piexif.load(img.info['exif'])
            
            # Add custom data in UserComment field
            user_comment = f"CHOPPED:{chopped_value}".encode('utf-8')
            exif_dict['Exif'][piexif.ExifIFD.UserComment] = user_comment
            
            # Also add in ImageDescription for redundancy
            exif_dict['0th'][piexif.ImageIFD.ImageDescription] = f"CHOPPED_LEVEL:{chopped_value}".encode('utf-8')
            
            # Convert back to bytes
            exif_bytes = piexif.dump(exif_dict)
            
            # Save over the original file
            if img.mode in ('RGBA', 'LA', 'P'):
                # Convert to RGB if necessary
                rgb_img = Image.new('RGB', img.size, (255, 255, 255))
                rgb_img.paste(img, mask=img.split()[-1] if img.mode != 'P' else None)
                img = rgb_img
            
            # Create backup first (optional safety measure)
            backup_path = self.selected_file + '.backup'
            try:
                import shutil
                shutil.copy2(self.selected_file, backup_path)
            except:
                pass  # Backup failed, continue anyway
            
            # Overwrite original file
            img.save(self.selected_file, exif=exif_bytes, quality=95)
            
            self.status_label.config(text=f"Successfully embedded level {chopped_value}!", foreground="green")
            messagebox.showinfo("Success", f"Original image updated with chopped level {chopped_value}!")
            
        except ValueError as e:
            messagebox.showerror("Error", str(e))
        except Exception as e:
            messagebox.showerror("Error", f"Failed to embed metadata: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = MetadataEmbedder(root)
    root.mainloop()